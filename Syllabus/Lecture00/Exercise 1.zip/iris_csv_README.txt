@ATTRIBUTE sepallength	REAL
@ATTRIBUTE sepalwidth 	REAL
@ATTRIBUTE petallength REAL
@ATTRIBUTE petalwidth	REAL
@ATTRIBUTE class: 1 = Setosa, 2 = Versicolor, 3 = Virginica
